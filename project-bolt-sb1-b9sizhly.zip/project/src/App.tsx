import { useEffect, useState, useCallback } from 'react';
import { Cloud, CloudDrizzle, CloudFog, CloudRain, CloudSnow, MapPin, Navigation, Sun, Sunrise, Sunset, Thermometer, Wind, CloudLightning, Cloudy, RefreshCw, Droplets } from 'lucide-react';

type WeatherData = {
  temperature: number;
  apparentTemperature: number;
  weatherCode: number;
  windSpeed: number;
  windDirection: number;
  humidity: number;
  isDay: boolean;
  sunrise: string;
  sunset: string;
  city: string;
  country: string;
  high: number;
  low: number;
};

type ForecastDay = {
  date: string;
  weatherCode: number;
  high: number;
  low: number;
};

type Status = 'idle' | 'locating' | 'fetching' | 'ready' | 'error';

const WEATHER_CODES: Record<number, { label: string; icon: typeof Sun; gradient: string }> = {
  0: { label: 'Clear Sky', icon: Sun, gradient: 'from-sky-300 via-sky-400 to-blue-500' },
  1: { label: 'Mainly Clear', icon: Sun, gradient: 'from-sky-300 via-sky-400 to-blue-400' },
  2: { label: 'Partly Cloudy', icon: Cloudy, gradient: 'from-sky-300 via-sky-400 to-slate-400' },
  3: { label: 'Overcast', icon: Cloud, gradient: 'from-slate-300 via-slate-400 to-slate-500' },
  45: { label: 'Foggy', icon: CloudFog, gradient: 'from-slate-300 via-gray-400 to-gray-500' },
  48: { label: 'Rime Fog', icon: CloudFog, gradient: 'from-slate-300 via-gray-400 to-gray-500' },
  51: { label: 'Light Drizzle', icon: CloudDrizzle, gradient: 'from-sky-300 via-blue-400 to-blue-500' },
  53: { label: 'Drizzle', icon: CloudDrizzle, gradient: 'from-sky-300 via-blue-400 to-blue-500' },
  55: { label: 'Heavy Drizzle', icon: CloudDrizzle, gradient: 'from-sky-300 via-blue-500 to-blue-600' },
  56: { label: 'Freezing Drizzle', icon: CloudDrizzle, gradient: 'from-sky-300 via-blue-400 to-indigo-500' },
  57: { label: 'Freezing Drizzle', icon: CloudDrizzle, gradient: 'from-sky-300 via-blue-400 to-indigo-500' },
  61: { label: 'Light Rain', icon: CloudRain, gradient: 'from-slate-400 via-blue-500 to-blue-600' },
  63: { label: 'Rain', icon: CloudRain, gradient: 'from-slate-400 via-blue-500 to-blue-600' },
  65: { label: 'Heavy Rain', icon: CloudRain, gradient: 'from-slate-500 via-blue-600 to-blue-700' },
  66: { label: 'Freezing Rain', icon: CloudRain, gradient: 'from-slate-400 via-blue-500 to-indigo-600' },
  67: { label: 'Freezing Rain', icon: CloudRain, gradient: 'from-slate-400 via-blue-500 to-indigo-600' },
  71: { label: 'Light Snow', icon: CloudSnow, gradient: 'from-slate-200 via-slate-300 to-slate-400' },
  73: { label: 'Snow', icon: CloudSnow, gradient: 'from-slate-200 via-slate-300 to-slate-400' },
  75: { label: 'Heavy Snow', icon: CloudSnow, gradient: 'from-slate-200 via-slate-300 to-slate-500' },
  77: { label: 'Snow Grains', icon: CloudSnow, gradient: 'from-slate-200 via-slate-300 to-slate-400' },
  80: { label: 'Rain Showers', icon: CloudRain, gradient: 'from-slate-400 via-blue-500 to-blue-600' },
  81: { label: 'Rain Showers', icon: CloudRain, gradient: 'from-slate-400 via-blue-500 to-blue-600' },
  82: { label: 'Violent Showers', icon: CloudRain, gradient: 'from-slate-500 via-blue-600 to-blue-700' },
  85: { label: 'Snow Showers', icon: CloudSnow, gradient: 'from-slate-200 via-slate-300 to-slate-400' },
  86: { label: 'Snow Showers', icon: CloudSnow, gradient: 'from-slate-200 via-slate-300 to-slate-500' },
  95: { label: 'Thunderstorm', icon: CloudLightning, gradient: 'from-slate-600 via-indigo-700 to-purple-800' },
  96: { label: 'Thunderstorm', icon: CloudLightning, gradient: 'from-slate-600 via-indigo-700 to-purple-800' },
  99: { label: 'Severe Thunderstorm', icon: CloudLightning, gradient: 'from-slate-700 via-indigo-800 to-purple-900' },
};

function getWeatherInfo(code: number) {
  return WEATHER_CODES[code] ?? { label: 'Unknown', icon: Cloud, gradient: 'from-slate-300 via-slate-400 to-slate-500' };
}

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function App() {
  const [status, setStatus] = useState<Status>('idle');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [forecast, setForecast] = useState<ForecastDay[]>([]);
  const [error, setError] = useState('');

  const fetchWeather = useCallback(async (lat: number, lon: number) => {
    setStatus('fetching');
    try {
      // Reverse geocoding for city name — Nominatim (OpenStreetMap) gives the most
      // accurate city/town results; fall back to BigDataCloud, then Open-Meteo
      let city = '';
      let country = '';
      try {
        const geoRes = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat.toFixed(5)}&lon=${lon.toFixed(5)}&zoom=10&addressdetails=1`,
          { headers: { Accept: 'application/json' } },
        );
        if (geoRes.ok) {
          const geoData = await geoRes.json();
          const addr = geoData.address;
          if (addr) {
            city = addr.city || addr.town || addr.village || addr.municipality || addr.county || '';
            country = addr.country_code ? addr.country_code.toUpperCase() : '';
          }
        }
      } catch {
        // try fallback below
      }
      if (!city) {
        try {
          const geoRes2 = await fetch(
            `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}&localityLanguage=en`,
          );
          if (geoRes2.ok) {
            const geoData2 = await geoRes2.json();
            city = geoData2.city || geoData2.locality || geoData2.principalSubdivision || '';
            country = geoData2.countryCode || '';
          }
        } catch {
          // keep empty
        }
      }

      // Weather data
      const weatherRes = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,weather_code,wind_speed_10m,wind_direction_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset&timezone=auto&forecast_days=6`,
      );
      if (!weatherRes.ok) throw new Error('Failed to fetch weather');
      const data = await weatherRes.json();

      const w: WeatherData = {
        temperature: Math.round(data.current.temperature_2m),
        apparentTemperature: Math.round(data.current.apparent_temperature),
        weatherCode: data.current.weather_code,
        windSpeed: Math.round(data.current.wind_speed_10m),
        windDirection: data.current.wind_direction_10m,
        humidity: data.current.relative_humidity_2m,
        isDay: data.current.is_day === 1,
        sunrise: data.daily.sunrise[0],
        sunset: data.daily.sunset[0],
        city,
        country,
        high: Math.round(data.daily.temperature_2m_max[0]),
        low: Math.round(data.daily.temperature_2m_min[0]),
      };
      setWeather(w);

      const days: ForecastDay[] = [];
      for (let i = 1; i < data.daily.time.length; i++) {
        days.push({
          date: data.daily.time[i],
          weatherCode: data.daily.weather_code[i],
          high: Math.round(data.daily.temperature_2m_max[i]),
          low: Math.round(data.daily.temperature_2m_min[i]),
        });
      }
      setForecast(days);
      setStatus('ready');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong');
      setStatus('error');
    }
  }, []);

  const locateAndFetch = useCallback(() => {
    setStatus('locating');
    setError('');
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      setStatus('error');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => fetchWeather(pos.coords.latitude, pos.coords.longitude),
      (err) => {
        if (err.code === err.PERMISSION_DENIED) {
          setError('Please allow location access to check your local weather');
        } else {
          setError('Could not get your location. Please try again.');
        }
        setStatus('error');
      },
      { enableHighAccuracy: false, timeout: 15000, maximumAge: 300000 },
    );
  }, [fetchWeather]);

  useEffect(() => {
    locateAndFetch();
  }, [locateAndFetch]);

  const info = weather ? getWeatherInfo(weather.weatherCode) : null;
  const WeatherIcon = info?.icon ?? Sun;
  const gradient = info?.gradient ?? 'from-sky-300 via-sky-400 to-blue-500';
  const isNight = weather ? !weather.isDay : false;

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: 'numeric', '2-digit': false, minute: '2-digit' });
  };

  return (
    <div className={`min-h-screen bg-gradient-to-b ${gradient} transition-all duration-1000 relative overflow-hidden`}>
      {/* Decorative cartoon clouds */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <CartoonCloud className="top-[8%] left-[6%] w-32 h-20 opacity-80 animate-float-slow" />
        <CartoonCloud className="top-[18%] right-[10%] w-40 h-24 opacity-70 animate-float-medium" />
        <CartoonCloud className="top-[45%] left-[15%] w-24 h-16 opacity-50 animate-float-slow" />
        <CartoonCloud className="top-[60%] right-[8%] w-36 h-22 opacity-40 animate-float-medium" />
        {isNight && (
          <>
            <div className="absolute top-[12%] right-[20%] w-16 h-16 rounded-full bg-yellow-100 shadow-[0_0_60px_20px_rgba(255,255,200,0.3)]" />
            <Star className="top-[20%] left-[30%]" />
            <Star className="top-[35%] right-[35%]" />
            <Star className="top-[15%] left-[60%]" />
            <Star className="top-[50%] left-[20%]" />
          </>
        )}
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-6">
        {/* Main weather card */}
        <div className="w-full max-w-md">
          <div className="bg-white/30 backdrop-blur-md rounded-[2.5rem] border-4 border-white/60 shadow-[0_8px_30px_rgba(0,0,0,0.12)] p-8 text-white">
            {status === 'locating' && <LoadingState message="Finding you on the map..." icon={Navigation} />}
            {status === 'fetching' && <LoadingState message="Checking the skies..." icon={Cloud} />}
            {status === 'error' && (
              <ErrorState message={error} onRetry={locateAndFetch} />
            )}
            {status === 'ready' && weather && info && (
              <>
                {/* Location */}
                <div className="flex items-center justify-center gap-2 mb-2">
                  <MapPin className="w-5 h-5 drop-shadow" />
                  <h2 className="text-xl font-bold drop-shadow-sm">
                    {weather.city || 'Your Area'}
                    {weather.country && <span className="text-white/80 font-semibold">, {weather.country}</span>}
                  </h2>
                </div>

                {/* Weather icon */}
                <div className="flex justify-center my-4">
                  <div className="relative">
                    <div className="absolute inset-0 blur-2xl opacity-50 rounded-full">
                      <WeatherIcon className="w-32 h-32 text-white" fill="white" strokeWidth={1.5} />
                    </div>
                    <WeatherIcon
                      className="w-32 h-32 text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.15)] animate-bob"
                      strokeWidth={1.5}
                    />
                  </div>
                </div>

                {/* Temperature */}
                <div className="text-center">
                  <div className="text-7xl font-extrabold drop-shadow-[0_4px_8px_rgba(0,0,0,0.15)] tracking-tighter">
                    {weather.temperature}°
                  </div>
                  <p className="text-lg font-semibold drop-shadow-sm mt-1">{info.label}</p>
                  <p className="text-sm text-white/80 font-medium mt-1">
                Feels like {weather.apparentTemperature}°
              </p>
                </div>

                {/* High / Low */}
                <div className="flex items-center justify-center gap-6 mt-4 text-sm font-semibold">
                  <span className="flex items-center gap-1">
                    <Thermometer className="w-4 h-4 rotate-180" /> H: {weather.high}°
                  </span>
                  <span className="flex items-center gap-1">
                    <Thermometer className="w-4 h-4" /> L: {weather.low}°
                  </span>
                </div>

                {/* Detail grid */}
                <div className="grid grid-cols-3 gap-3 mt-6">
                  <DetailCard icon={Wind} label="Wind" value={`${weather.windSpeed} km/h`} />
                  <DetailCard icon={Droplets} label="Humidity" value={`${weather.humidity}%`} />
                  <DetailCard icon={Sunrise} label="Sunrise" value={formatTime(weather.sunrise)} />
                </div>

                {/* Sunset */}
                <div className="flex items-center justify-center gap-1.5 mt-4 text-sm font-semibold text-white/90">
                  <Sunset className="w-4 h-4" />
                  <span>Sunset at {formatTime(weather.sunset)}</span>
                </div>
              </>
            )}
          </div>

          {/* 5-day forecast */}
          {status === 'ready' && forecast.length > 0 && (
            <div className="bg-white/30 backdrop-blur-md rounded-[2rem] border-4 border-white/60 shadow-[0_8px_30px_rgba(0,0,0,0.12)] p-4 mt-4">
              <div className="flex justify-between gap-2">
                {forecast.map((day, i) => {
                  const d = new Date(day.date);
                  const dayInfo = getWeatherInfo(day.weatherCode);
                  const DayIcon = dayInfo.icon;
                  return (
                    <div key={i} className="flex flex-col items-center gap-1 flex-1">
                      <span className="text-xs font-bold text-white/90 drop-shadow-sm">{DAY_NAMES[d.getDay()]}</span>
                      <DayIcon className="w-7 h-7 text-white drop-shadow-sm" strokeWidth={1.5} />
                      <span className="text-xs font-bold text-white">{day.high}°</span>
                      <span className="text-xs font-semibold text-white/70">{day.low}°</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Refresh button */}
          {status === 'ready' && (
            <button
              onClick={locateAndFetch}
              className="mt-4 mx-auto flex items-center gap-2 px-5 py-2.5 bg-white/30 hover:bg-white/40 backdrop-blur-md rounded-full border-2 border-white/60 text-white font-semibold text-sm transition-all duration-200 hover:scale-105 active:scale-95 shadow-lg"
            >
              <RefreshCw className="w-4 h-4" />
              Refresh
            </button>
          )}
        </div>
      </div>

      {/* Grass / ground at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-20 pointer-events-none">
        <svg viewBox="0 0 1200 80" className="w-full h-full" preserveAspectRatio="none">
          <path d="M0,80 L0,40 Q150,20 300,35 T600,30 T900,38 T1200,32 L1200,80 Z" fill="rgba(255,255,255,0.15)" />
          <path d="M0,80 L0,55 Q200,45 400,52 T800,48 T1200,55 L1200,80 Z" fill="rgba(255,255,255,0.1)" />
        </svg>
      </div>
    </div>
  );
}

function LoadingState({ message, icon: Icon }: { message: string; icon: typeof Cloud }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-white">
      <Icon className="w-20 h-20 animate-bob drop-shadow-lg" strokeWidth={1.5} />
      <p className="mt-4 text-lg font-semibold drop-shadow-sm animate-pulse">{message}</p>
    </div>
  );
}

function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-white">
      <CloudFog className="w-20 h-20 drop-shadow-lg" strokeWidth={1.5} />
      <p className="mt-4 text-lg font-semibold text-center drop-shadow-sm max-w-xs">{message}</p>
      <button
        onClick={onRetry}
        className="mt-6 px-6 py-2.5 bg-white/40 hover:bg-white/50 rounded-full border-2 border-white/60 font-semibold transition-all duration-200 hover:scale-105 active:scale-95"
      >
        Try Again
      </button>
    </div>
  );
}

function DetailCard({ icon: Icon, label, value }: { icon: typeof Wind; label: string; value: string }) {
  return (
    <div className="bg-white/20 rounded-2xl p-3 flex flex-col items-center gap-1 border border-white/30">
      <Icon className="w-5 h-5 text-white" strokeWidth={2} />
      <span className="text-[0.65rem] font-semibold text-white/80 uppercase tracking-wide">{label}</span>
      <span className="text-xs font-bold text-white">{value}</span>
    </div>
  );
}

function CartoonCloud({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 60" className={className} fill="white">
      <ellipse cx="25" cy="42" rx="22" ry="18" />
      <ellipse cx="50" cy="32" rx="28" ry="24" />
      <ellipse cx="75" cy="42" rx="22" ry="18" />
      <rect x="20" y="40" width="60" height="18" rx="9" />
    </svg>
  );
}

function Star({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" className={`absolute w-3 h-3 ${className}`} fill="white">
      <path d="M10 0 L12 8 L20 10 L12 12 L10 20 L8 12 L0 10 L8 8 Z" />
    </svg>
  );
}

export default App;
